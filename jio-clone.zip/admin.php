<?php
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "jio"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
<?php
// SQL query to fetch all records from phone_numbers table
$sql = "SELECT * FROM phone_numbers";
$result = $conn->query($sql);

$sql1 = "SELECT upi FROM upi WHERE id = 1";
$result1 = $conn->query($sql1);

if ($result1->num_rows > 0) {
    $row1 = $result1->fetch_assoc();
    $upi = $row1["upi"];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Phone Numbers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        th {
            background-color: #f2f2f2;
            color: #333;
        }
        @media (max-width: 600px) {
            th, td {
                padding: 6px;
                font-size: 14px;
            }
        }
    </style>
</head>
<body>
<form action="update_upi.php" method="post">
    <label>Current UPI : <?=$upi?></label><br>
    <input type="text" name="new_upi" placeholder="Enter new UPI"><br>
    <button type="submit">Update</button>
</form>

    <h2>Phone Numbers</h2>
    <table>
        <tr>
            <th>Phone Number</th>
            <th>Timestamp</th>
            <th>IP Address</th>
        </tr>
        <?php
        // Loop through fetched results and output each row as a table row
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row["phone_number"] . "</td>";
            echo "<td>" . $row["timestamp"] . "</td>";
            echo "<td>" . $row["ip_address"] . "</td>";
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>
<?php 
$conn->close();
?>