<?php
// Assuming your database connection details
$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "jio"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Process the new UPI value from the form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_upi = $_POST["new_upi"];

    // Update the UPI in your database
    $sql = "UPDATE upi SET upi = '$new_upi' WHERE id = 1"; // Assuming id = 1 for the row you want to update
    if ($conn->query($sql) === TRUE) {
        echo "UPI updated successfully";
    } else {
        echo "Error updating UPI: " . $conn->error;
    }
}

$conn->close();
?>
